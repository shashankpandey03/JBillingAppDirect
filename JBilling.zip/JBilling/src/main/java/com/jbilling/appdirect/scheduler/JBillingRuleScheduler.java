package com.jbilling.appdirect.scheduler;

public interface JBillingRuleScheduler {
	
	public void fetchRule();
}
