package com.jbilling.appdirect.processor.decorator;

import com.jbilling.appdirect.processor.IRuleProcessor;

public abstract class IRuleProcessorDecorator extends IRuleProcessor {

}
