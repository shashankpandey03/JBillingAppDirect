package com.jbilling.appdirect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JBillingApplication {

	public static void main(String[] args) {
		SpringApplication.run(JBillingApplication.class, args);
	}
}
