package com.jbilling.appdirect.scheduler;

public interface IdealPriceCalculatorScheduler {

	public void processPriceCalculatorJob();
}
