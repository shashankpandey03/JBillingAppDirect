package com.jbilling.appdirect.service;

import java.util.List;

import com.jbilling.appdirect.domain.entity.Rules;

public interface RuleService {

	public List<Rules> fetchRules();
}
